import csv
from posixpath import split
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.font_manager as fm
import glob
import os
import re

def myround(x, base):
    return base * round((x + base)/base)

def stepsize(x):
    if x < 501:
        return 50
    if x < 1001:
        return 100
    if x < 5001:
        return 500
    if x < 10001:
        return 1000

# name:     string, including dash.                         ex: BSA-EGCG
# conc:     float, concentration in mM.                     ex: 0.0125mM
# ex_em:    float, excitation/em bandwidth.                 ex: 2.5
# resp:     int, response time in msec.                     ex: 100msec
# sens:     int, sensitivity with low=1, med=2, high=3.     ex: 2
def getHash(name: str, conc: float, ex_em: float, resp: int, sens: int) -> int:
    sum = 0
    # name
    for c in name:
        sum += ord(c)
    # conc
    sum += int(conc * 110000)
    # ex_em
    sum += int(ex_em * 50)
    # resp
    sum += resp * 7

    return int(sum << sens)


fe = fm.FontEntry(
    fname='./fonts/Helvetica-Bold.ttf',
    name='helvetica-bold')
fm.fontManager.ttflist.insert(0, fe)
plt.rcParams['font.family'] = fe.name

filepaths = glob.glob('./csvs/*/*/*/*/*.csv')
""" temp_set = set() """
for path in filepaths:
    filename = os.path.basename(path)
    #print("Working on " + filename + " at " + path)

    with open(path) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        temp = list(csv_reader)
        mat = np.array(temp[19:220])
        if np.ma.size(mat, axis=1) > 2:
            mat = np.delete(mat, 2, axis=1)
        mat = mat.astype(np.float32)
        mat = np.transpose(mat)
        
        x, y = mat
        plt.figure(figsize=(10.65,5.52))
        plt.plot(x, y, linewidth=4)

        charcoal = '#595959'

        plt.xlabel('Wavelength (nm)', fontsize=20, color=charcoal)
        plt.xticks(fontsize=14, color=charcoal)
        plt.xlim([300, 500])
        plt.xticks(np.arange(min(x), max(x)+1, 20))

        plt.ylabel('Fluorescence Intensity', fontsize=20, color=charcoal)
        plt.yticks(fontsize=14, color=charcoal)
        plt.ylim([0, myround(max(y),stepsize(max(y)))])
        plt.yticks(np.arange(0, myround(max(y),stepsize(max(y)))+1, stepsize(max(y))))

        plt.subplots_adjust(bottom=.15)

        split_path = path.split('/')
        name = split_path[2]
        conc = float(re.search('([0][.].+?)mM', split_path[3]).group(1))
        ex_em = float(temp[253][1].split(' ')[0])
        resp = temp[255][1].split(' ')
        if resp[1] == 'sec':
            resp = int(float(resp[0]) * 1000)
        else:
            resp = int(resp[0])
        sens = temp[256][1]
        if sens == 'Low':
            sens = 1
        elif sens == 'Medium':
            sens = 2
        elif sens == 'High':
            sens = 3

        """ val = getHash(name, conc, ex_em, resp, sens)
        if val == 13024:
            print(filename)
        if val in temp_set:
            print(val)
        else:
            temp_set.add(val) """
        
        plt.savefig("./out/" + str(getHash(name, conc, ex_em, resp, sens)) + ".svg")
        plt.close()

""" print(len(temp_set)) """